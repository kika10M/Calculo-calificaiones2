import { useState, useEffect } from "react";

const TOTAL_MATERIAS = 5;
const TOTAL_CALIFICACIONES = 3;
const vacias = () => Array(TOTAL_CALIFICACIONES).fill("");
const dos = (n) => n.toFixed(2);
const aprobado = (n) => (n >= 70 ? "aprobado" : "reprobado");

// Número que sube animado hasta su valor final
function Contador({ valor }) {
  const [v, setV] = useState(0);
  useEffect(() => {
    let inicio = null;
    let id;
    const paso = (t) => {
      if (inicio === null) inicio = t;
      const p = Math.min((t - inicio) / 1200, 1);
      setV(valor * (1 - Math.pow(1 - p, 3)));
      if (p < 1) id = requestAnimationFrame(paso);
    };
    id = requestAnimationFrame(paso);
    return () => cancelAnimationFrame(id);
  }, [valor]);
  return <>{dos(v)}</>;
}

export default function App() {
  // ---- Declaración de variables ----
  const [paso, setPaso] = useState("datos"); // datos -> materia -> final
  const [nombre, setNombre] = useState("");
  const [matricula, setMatricula] = useState("");
  const [i, setI] = useState(1);
  const [nombreMateria, setNombreMateria] = useState("");
  const [calificaciones, setCalificaciones] = useState(vacias());
  const [promedioMateria, setPromedioMateria] = useState(null);
  const [sumaPromedios, setSumaPromedios] = useState(0); // sumaPromedios <- 0
  const [promedioGeneral, setPromedioGeneral] = useState(null);
  const [materias, setMaterias] = useState([]);
  const [error, setError] = useState("");

  // ---- 1. Datos generales ----
  const guardarDatos = (e) => {
    e.preventDefault();
    if (!nombre.trim() || !matricula.trim()) {
      setError("Escribe el nombre y la matrícula del alumno.");
      return;
    }
    setError("");
    setPaso("materia");
  };

  // ---- 2. Ciclo para las 5 materias ----
  const calcularPromedio = (e) => {
    e.preventDefault();
    const invalida = calificaciones.some(
      (c) => c === "" || Number(c) < 0 || Number(c) > 100
    );
    if (!nombreMateria.trim() || invalida) {
      setError("Escribe el nombre de la materia y 3 calificaciones entre 0 y 100.");
      return;
    }
    setError("");
    let sumaCalificaciones = 0; // sumaCalificaciones <- 0
    for (let j = 1; j <= TOTAL_CALIFICACIONES; j++) {
      sumaCalificaciones = sumaCalificaciones + Number(calificaciones[j - 1]);
    }
    setPromedioMateria(sumaCalificaciones / TOTAL_CALIFICACIONES); // / 3
  };

  const siguienteMateria = () => {
    const nuevaSuma = sumaPromedios + promedioMateria; // sumaPromedios + promedioMateria
    setSumaPromedios(nuevaSuma);
    setMaterias([...materias, { nombre: nombreMateria, promedio: promedioMateria }]);
    if (i === TOTAL_MATERIAS) {
      setPromedioGeneral(nuevaSuma / TOTAL_MATERIAS); // promedioGeneral <- suma / 5
      setPaso("final");
    } else {
      setI(i + 1);
      setNombreMateria("");
      setCalificaciones(vacias());
      setPromedioMateria(null);
    }
  };

  const cambiarCalificacion = (j, valor) =>
    setCalificaciones(calificaciones.map((c, k) => (k === j ? valor : c)));

  const reiniciar = () => {
    setPaso("datos"); setNombre(""); setMatricula(""); setI(1);
    setNombreMateria(""); setCalificaciones(vacias()); setPromedioMateria(null);
    setSumaPromedios(0); setPromedioGeneral(null); setMaterias([]); setError("");
  };

  return (
    <main className="tarjeta">
      <header className="cabecera">
        <h1>Registro de calificaciones</h1>
        {paso !== "datos" && (
          <div className="puntos" aria-label="Progreso">
            {Array.from({ length: TOTAL_MATERIAS }, (_, k) => (
              <span
                key={k}
                className={
                  "punto " +
                  (paso === "final" || k + 1 < i ? "listo" : k + 1 === i ? "actual" : "")
                }
              />
            ))}
          </div>
        )}
      </header>

      {paso === "datos" && (
        <form key="datos" className="pantalla" onSubmit={guardarDatos}>
          <h2>1. Datos generales</h2>
          <label>
            Ingresa nombre del alumno:
            <input value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder="Ej. Ana López" />
          </label>
          <label>
            Ingresa matrícula del alumno:
            <input value={matricula} onChange={(e) => setMatricula(e.target.value)} placeholder="Ej. A01234567" />
          </label>
          {error && <p className="error">{error}</p>}
          <button type="submit">Continuar</button>
        </form>
      )}

      {paso === "materia" && (
        <form key={"materia" + i} className="pantalla" onSubmit={calcularPromedio}>
          <p className="alumno">{nombre} · {matricula}</p>
          <h2>---- Materia {i} de {TOTAL_MATERIAS} ----</h2>
          <fieldset disabled={promedioMateria !== null}>
            <label>
              Ingresa nombre de la materia:
              <input value={nombreMateria} onChange={(e) => setNombreMateria(e.target.value)} />
            </label>
            <div className="notas">
              {calificaciones.map((c, j) => (
                <label key={j}>
                  Calificación {j + 1}:
                  <input
                    type="number" min="0" max="100" value={c}
                    onChange={(e) => cambiarCalificacion(j, e.target.value)}
                  />
                </label>
              ))}
            </div>
          </fieldset>
          {error && <p className="error">{error}</p>}

          {promedioMateria === null ? (
            <button type="submit">Calcular promedio</button>
          ) : (
            <>
              <div className={"resultado " + aprobado(promedioMateria)}>
                <span>El promedio de {nombreMateria} es:</span>
                <strong>{dos(promedioMateria)}</strong>
              </div>
              <button type="button" onClick={siguienteMateria}>
                {i === TOTAL_MATERIAS ? "Ver promedio general" : "Siguiente materia"}
              </button>
            </>
          )}
        </form>
      )}

      {paso === "final" && (
        <section key="final" className="pantalla">
          <p className="alumno">{nombre} · {matricula}</p>
          <ul className="lista">
            {materias.map((m, k) => (
              <li key={k} style={{ animationDelay: k * 0.12 + "s" }}>
                <div className="fila">
                  <span>{m.nombre}</span>
                  <b className={aprobado(m.promedio)}>{dos(m.promedio)}</b>
                </div>
                <div className="barra">
                  <div
                    className={"relleno " + aprobado(m.promedio)}
                    style={{ width: m.promedio + "%", animationDelay: k * 0.12 + "s" }}
                  />
                </div>
              </li>
            ))}
          </ul>
          <div className={"general " + aprobado(promedioGeneral)}>
            <span>Promedio general</span>
            <strong><Contador valor={promedioGeneral} /></strong>
            <em>{promedioGeneral >= 70 ? "¡Aprobado!" : "Reprobado"}</em>
          </div>
          <button onClick={reiniciar}>Registrar otro alumno</button>
        </section>
      )}
    </main>
  );
}
